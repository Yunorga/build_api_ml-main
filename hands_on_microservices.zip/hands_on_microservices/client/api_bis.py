import streamlit as st
from streamlit_drawable_canvas import st_canvas
import requests
from io import BytesIO
from PIL import Image

# URL de l'API
API_IMG_UPLOAD_URL = "http://serveur:8000/img_upload"
API_PREDICT_URL = "http://serveur:8000/predict_shape"

st.set_page_config(page_title="Reconnaissance de formes", layout="centered")

st.title("🖌️ Dessinez une forme et obtenez une prédiction !")

# 🎯 Instructions pour l'utilisateur
st.markdown(
    """
    **Instructions :**
    1. Dessinez une des formes suivantes sur le canvas :
       - **Cercle**
       - **Triangle**
       - **Carré**
       - **Pentagone**
       - **Hexagone**
    2. Cliquez sur **"Submit and Predict"** pour envoyer votre dessin au serveur.
    3. Le serveur analysera votre dessin et affichera la forme détectée.
    """
)

# 🎨 Paramètres du canvas
stroke_width = st.slider("Épaisseur du trait :", 1, 25, 3)
stroke_color = st.color_picker("Couleur du trait :")
bg_color = st.color_picker("Couleur de fond :", "#FFFFFF")

width, height = 300, 300  # Taille du canvas

# 📜 Sélection du mode de dessin
drawing_mode = st.selectbox(
    "Outil de dessin :", ("freedraw", "line", "rect", "circle", "transform", "polygon")
)

# 🖍️ Création du canvas
canvas_result = st_canvas(
    fill_color="rgba(255, 165, 0, 0.3)",
    stroke_width=stroke_width,
    stroke_color=stroke_color,
    background_color=bg_color,
    update_streamlit=True,
    height=height,
    width=width,
    drawing_mode=drawing_mode,
    key="canvas",
)

# 📤 Bouton pour soumettre le dessin
if st.button("Submit and Predict"):
    if canvas_result.image_data is not None:
        # Convertir le dessin en image
        img = Image.fromarray(canvas_result.image_data.astype('uint8'), 'RGBA')
        img_bytes = BytesIO()
        img.save(img_bytes, format="PNG")
        img_bytes = img_bytes.getvalue()

        # Envoyer l'image au serveur pour prédiction
        response = requests.post(API_PREDICT_URL, files={"file": ("image.png", img_bytes, "image/png")})

        if response.status_code == 200:
            prediction = response.json().get("shape", "Inconnue")
            st.success(f"✅ Forme détectée : **{prediction}**")
        else:
            st.error(f"❌ Erreur lors de la prédiction : {response.text}")
    else:
        st.warning("⚠️ Veuillez dessiner une forme avant de soumettre.")
